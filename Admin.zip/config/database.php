<?php
$host ="sql211.infinityfree.com";
$user = "if0_41648118_db_inventaris";
$pass = "t7igmbaLep";
$db = "inventaris";

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Koneksi Gagal: " . mysqli_connect_error());
}
?>